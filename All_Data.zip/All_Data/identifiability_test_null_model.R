
# ==============================================================================
# Reaction-norm slope-intercept null test
# ==============================================================================
#
# Purpose
# -------
# Test whether an empirical association between group-specific reaction-norm
# intercepts and slopes is more extreme than expected when the *latent* group
# intercepts and slopes are uncorrelated.
#
# The procedure is a parametric bootstrap:
#   1. Fit response ~ predictor separately within each group.
#   2. Estimate an independent random-intercept/random-slope null model by
#      maximum likelihood while retaining the observed sampling design.
#   3. Simulate many complete response vectors under that null model using the
#      exact predictor values, group sizes, imbalance, and replication in the
#      supplied data.
#   4. Refit the within-group regressions after every simulation.
#   5. Build null distributions of recovered slope-intercept correlations and/or
#      covariances.
#   6. Calculate Monte Carlo two-tailed p-values relative to the centre of each
#      induced null distribution.
#
# ==============================================================================

reaction_norm_null_test <- function(
    data,
    response,
    predictor,
    group,
    statistic = c("correlation", "covariance", "both"),
    n_sims = 2000L,
    center_predictor = FALSE,
    predictor_center = NULL,
    min_group_n = 3L,
    seed = NULL,
    optimizer_control = list(maxit = 1000),
    keep_simulated_fits = FALSE,
    #test original intercept after centering if you want
    test_uncentered_intercept = FALSE,
    #what kind of test to use?
    alternative = c("two.sided", "less", "greater"),
    progress = interactive()
) {
  # ---------------------------------------------------------------------------
  # 0. Validate arguments and capture column names
  # ---------------------------------------------------------------------------
  if (!is.data.frame(data)) stop("`data` must be a data.frame.")
  
  # Accept either bare names, e.g. response = y, or strings, e.g. response = "y".
  # We inspect the unevaluated expression so a bare column name need not exist as
  # a separate object in the calling environment.
  get_col_name <- function(arg_expr) {
    if (is.character(arg_expr) && length(arg_expr) == 1L) return(arg_expr)
    deparse(arg_expr)
  }
  
  response_name  <- get_col_name(substitute(response))
  predictor_name <- get_col_name(substitute(predictor))
  group_name     <- get_col_name(substitute(group))
  
  needed <- c(response_name, predictor_name, group_name)
  missing_cols <- setdiff(needed, names(data))
  if (length(missing_cols) > 0L) {
    stop("Columns not found in `data`: ", paste(missing_cols, collapse = ", "))
  }
  
  statistic <- match.arg(statistic)
  alternative <- match.arg(alternative)
  n_sims <- as.integer(n_sims)
  min_group_n <- as.integer(min_group_n)
  if (!is.finite(n_sims) || n_sims < 1L) stop("`n_sims` must be at least 1.")
  if (!is.finite(min_group_n) || min_group_n < 2L) {
    stop("`min_group_n` must be at least 2.")
  }
  if (!is.null(seed)) set.seed(seed)
  
  # Make a small internal data frame with stable names. Rows with missing or
  # non-finite response/predictor values, or missing groups, cannot be fitted.
  dat <- data.frame(
    y = data[[response_name]],
    x_original = data[[predictor_name]],
    group = data[[group_name]],
    stringsAsFactors = FALSE
  )
  
  if (!is.numeric(dat$y)) stop("The response column must be numeric.")
  if (!is.numeric(dat$x_original)) stop("The predictor column must be numeric.")
  
  keep <- is.finite(dat$y) & is.finite(dat$x_original) & !is.na(dat$group)
  n_removed_missing <- sum(!keep)
  dat <- dat[keep, , drop = FALSE]
  if (nrow(dat) == 0L) stop("No complete, finite observations remain.")
  
  # Define the predictor origin. predictor_center has precedence. This is useful
  # because slope-intercept covariance depends strongly on the predictor origin.
  if (!is.null(predictor_center)) {
    if (length(predictor_center) != 1L || !is.finite(predictor_center)) {
      stop("`predictor_center` must be one finite number.")
    }
    x_center <- as.numeric(predictor_center)
  } else if (isTRUE(center_predictor)) {
    x_center <- mean(dat$x_original)
  } else {
    x_center <- 0
  }
  dat$x <- dat$x_original - x_center
  
  recover_original_intercept <- function(intercept, slope, center_value) {
    intercept - slope * center_value
  }
  
  # Retain only groups capable of yielding a slope: enough rows and at least two
  # distinct predictor values. The same retained design is used in every bootstrap.
  split_initial <- split(dat, dat$group, drop = TRUE)
  valid_group <- vapply(
    split_initial,
    function(d) nrow(d) >= min_group_n && length(unique(d$x)) >= 2L,
    logical(1)
  )
  excluded_groups <- names(split_initial)[!valid_group]
  group_data <- split_initial[valid_group]
  if (length(group_data) < 3L) {
    stop("At least three valid groups are required to estimate an association.")
  }
  
  # Recombine and create integer group IDs. `group_data` preserves each group's
  # original row-level predictor pattern, including imbalance and replication.
  dat <- do.call(rbind, group_data)
  rownames(dat) <- NULL
  group_labels <- names(group_data)
  n_groups <- length(group_data)
  
  # ---------------------------------------------------------------------------
  # 1. Helper: fit separate OLS reaction norms and extract intercepts/slopes
  # ---------------------------------------------------------------------------
  fit_group_lines <- function(y_by_group, x_by_group, labels) {
    out <- matrix(NA_real_, nrow = length(labels), ncol = 2L,
                  dimnames = list(NULL, c("intercept", "slope")))
    for (g in seq_along(labels)) {
      Xg <- cbind(1, x_by_group[[g]])
      # qr.coef is numerically stable and avoids repeatedly constructing lm objects.
      out[g, ] <- qr.coef(qr(Xg), y_by_group[[g]])
    }
    data.frame(
      group = labels,
      intercept = out[, "intercept"],
      slope = out[, "slope"],
      stringsAsFactors = FALSE
    )
  }
  
  x_by_group <- lapply(group_data, `[[`, "x")
  y_by_group <- lapply(group_data, `[[`, "y")
  empirical_fits <- fit_group_lines(y_by_group, x_by_group, group_labels)
  
  # Defensive check. This should not fail after the group validity screening.
  finite_fit <- is.finite(empirical_fits$intercept) & is.finite(empirical_fits$slope)
  if (sum(finite_fit) < 3L) stop("Fewer than three finite group fits were obtained.")
  empirical_fits <- empirical_fits[finite_fit, , drop = FALSE]
  
  empirical_intercepts <- empirical_fits$intercept
  
  if (test_uncentered_intercept) {
    empirical_intercepts <- recover_original_intercept(
      empirical_fits$intercept,
      empirical_fits$slope,
      x_center
    )
  }
  
  empirical_correlation <- cor(
    empirical_intercepts,
    empirical_fits$slope
  )
  
  empirical_covariance <- cov(
    empirical_intercepts,
    empirical_fits$slope
  )
  
  # ---------------------------------------------------------------------------
  # 2. Fit the independent latent intercept/slope null by maximum likelihood
  # ---------------------------------------------------------------------------
  # Model for group g:
  #   y_g = X_g beta + X_g b_g + e_g
  #   b_g ~ N(0, diag(tau_intercept^2, tau_slope^2))
  #   e_g ~ N(0, sigma_e^2 I)
  #
  # Thus y_g marginally follows:
  #   N(X_g beta, X_g D X_g' + sigma_e^2 I)
  # where D is diagonal. The diagonal D explicitly imposes zero latent
  # slope-intercept covariance. We maximize the marginal likelihood by `optim`.
  
  X_by_group <- lapply(x_by_group, function(x) cbind(1, x))
  
  # Starting fixed effects come from an ordinary regression over all retained rows.
  beta_start <- as.numeric(qr.coef(qr(cbind(1, dat$x)), dat$y))
  if (any(!is.finite(beta_start))) stop("Could not obtain starting fixed effects.")
  
  # Obtain stable positive starting variances. The residual start is pooled across
  # group-specific regressions. 
  rss <- 0
  residual_df <- 0L
  for (g in seq_along(group_data)) {
    Xg <- X_by_group[[g]]
    yg <- y_by_group[[g]]
    bg <- qr.coef(qr(Xg), yg)
    rss <- rss + sum((yg - drop(Xg %*% bg))^2)
    residual_df <- residual_df + nrow(Xg) - 2L
  }
  total_var <- var(dat$y)
  variance_floor <- max(total_var, 1, na.rm = TRUE) * 1e-10
  sigma2_start <- if (residual_df > 0L) rss / residual_df else total_var / 4
  sigma2_start <- max(sigma2_start, variance_floor)
  tau_a2_start <- max(var(empirical_fits$intercept) / 2, variance_floor)
  tau_b2_start <- max(var(empirical_fits$slope) / 2, variance_floor)
  
  # Parameters are beta0, beta1, log(tau_a^2), log(tau_b^2), log(sigma_e^2).
  # Log-variances guarantee positive variance estimates during optimization.
  neg_log_likelihood <- function(par) {
    beta <- par[1:2]
    variance_values <- exp(par[3:5])
    if (any(!is.finite(variance_values))) return(.Machine$double.xmax / 100)
    D <- diag(variance_values[1:2], nrow = 2L)
    sigma2 <- variance_values[3]
    nll <- 0
    
    for (g in seq_along(X_by_group)) {
      Xg <- X_by_group[[g]]
      yg <- y_by_group[[g]]
      Vg <- Xg %*% D %*% t(Xg) + diag(sigma2, nrow(Xg))
      R <- tryCatch(chol(Vg), error = function(e) NULL)
      if (is.null(R)) return(.Machine$double.xmax / 100)
      residual <- yg - drop(Xg %*% beta)
      # If R'R = V, then ||solve(R', residual)||^2 = residual' V^-1 residual.
      z <- forwardsolve(t(R), residual)
      log_det <- 2 * sum(log(diag(R)))
      nll <- nll + 0.5 * (length(yg) * log(2 * pi) + log_det + sum(z^2))
    }
    nll
  }
  
  start <- c(beta_start,
             log(tau_a2_start), log(tau_b2_start), log(sigma2_start))
  opt <- optim(
    par = start,
    fn = neg_log_likelihood,
    method = "BFGS",
    control = optimizer_control,
    hessian = FALSE
  )
  if (opt$convergence != 0L || !is.finite(opt$value)) {
    warning("Null-model optimization did not report clean convergence: ",
            opt$message %||% paste("convergence code", opt$convergence))
  }
  
  beta_hat <- unname(opt$par[1:2])
  names(beta_hat) <- c("mean_intercept", "mean_slope")
  variances_hat <- exp(opt$par[3:5])
  names(variances_hat) <- c("intercept_variance", "slope_variance",
                            "residual_variance")
  
  # ---------------------------------------------------------------------------
  # 3. Parametric bootstrap under zero latent intercept-slope covariance
  # ---------------------------------------------------------------------------
  null_correlation <- rep(NA_real_, n_sims)
  null_covariance  <- rep(NA_real_, n_sims)
  
  if (isTRUE(keep_simulated_fits)) {
    simulated_fits <- vector("list", n_sims)
  } else {
    simulated_fits <- NULL
  }
  
  progress_points <- if (isTRUE(progress) && n_sims >= 10L) {
    unique(round(seq(1, n_sims, length.out = 11L))[-1L])
  } else integer(0)
  
  for (s in seq_len(n_sims)) {
    # Draw independent latent deviations. Independence is the biological/statistical
    # null; any association among the subsequently recovered OLS coefficients is
    # generated by their shared design and observation error.
    latent_intercept <- rnorm(
      n_groups, mean = beta_hat[1], sd = sqrt(variances_hat[1])
    )
    latent_slope <- rnorm(
      n_groups, mean = beta_hat[2], sd = sqrt(variances_hat[2])
    )
    
    sim_y <- vector("list", n_groups)
    for (g in seq_len(n_groups)) {
      xg <- x_by_group[[g]]
      sim_y[[g]] <- latent_intercept[g] + latent_slope[g] * xg +
        rnorm(length(xg), mean = 0, sd = sqrt(variances_hat[3]))
    }
    
    recovered <- fit_group_lines(sim_y, x_by_group, group_labels)
    good <- is.finite(recovered$intercept) & is.finite(recovered$slope)
    recovered <- recovered[good, , drop = FALSE]
    
    intercepts_to_test <- recovered$intercept
    
    if (test_uncentered_intercept) {
      intercepts_to_test <- recover_original_intercept(
        recovered$intercept,
        recovered$slope,
        x_center
      )
    }
    
    if (nrow(recovered) >= 3L &&
        sd(intercepts_to_test) > 0 &&
        sd(recovered$slope) > 0) {
      
      null_correlation[s] <- cor(
        intercepts_to_test,
        recovered$slope
      )
      
      null_covariance[s] <- cov(
        intercepts_to_test,
        recovered$slope
      )
    }
    if (isTRUE(keep_simulated_fits)) simulated_fits[[s]] <- recovered
    
    if (s %in% progress_points) {
      message(sprintf("Parametric bootstrap: %d%% complete",
                      round(100 * s / n_sims)))
    }
  }
  
  # ---------------------------------------------------------------------------
  # 4. Two-tailed Monte Carlo p-values
  # ---------------------------------------------------------------------------
  # The recovered null distribution can be centred away from zero because OLS
  # intercept and slope errors are mathematically associated. Therefore, extremity
  # is measured relative to the simulated null centre, not automatically zero.
  # The +1 correction prevents an estimated p-value of exactly zero.
  monte_carlo_p <- function(
    observed,
    null_values,
    alternative = c("two.sided", "less", "greater")
  ) {
    alternative <- match.arg(alternative)
    z <- null_values[is.finite(null_values)]
    if (length(z) == 0L) {
      return(NA_real_)
    }
    null_center <- mean(z)
    if (alternative == "two.sided") {
      p <- (1 + sum(
        abs(z - null_center) >=
          abs(observed - null_center)
      )) / (length(z) + 1)
    } else if (alternative == "less") {
      p <- (1 + sum(
        z <= observed
      )) / (length(z) + 1)
    } else {   # greater
      p <- (1 + sum(
        z >= observed
      )) / (length(z) + 1)
    }
    p
  }
  
  
  p_correlation <- monte_carlo_p(
    empirical_correlation,
    null_correlation,
    alternative
  )
  
  p_covariance <- monte_carlo_p(
    empirical_covariance,
    null_covariance,
    alternative
  )
  
  summary_all <- data.frame(
    statistic = c("correlation", "covariance"),
    empirical = c(empirical_correlation, empirical_covariance),
    null_mean = c(mean(null_correlation, na.rm = TRUE),
                  mean(null_covariance, na.rm = TRUE)),
    null_median = c(median(null_correlation, na.rm = TRUE),
                    median(null_covariance, na.rm = TRUE)),
    null_sd = c(sd(null_correlation, na.rm = TRUE),
                sd(null_covariance, na.rm = TRUE)),
    null_q025 = c(unname(quantile(null_correlation, 0.025, na.rm = TRUE)),
                  unname(quantile(null_covariance, 0.025, na.rm = TRUE))),
    null_q975 = c(unname(quantile(null_correlation, 0.975, na.rm = TRUE)),
                  unname(quantile(null_covariance, 0.975, na.rm = TRUE))),
    p_value = c(p_correlation, p_covariance),
    valid_simulations = c(sum(is.finite(null_correlation)),
                          sum(is.finite(null_covariance))),
    stringsAsFactors = FALSE
  )
  
  selected_rows <- switch(
    statistic,
    correlation = 1L,
    covariance = 2L,
    both = 1:2
  )
  summary_selected <- summary_all[selected_rows, , drop = FALSE]
  null_selected <- switch(
    statistic,
    correlation = data.frame(simulation = seq_len(n_sims),
                             correlation = null_correlation),
    covariance = data.frame(simulation = seq_len(n_sims),
                            covariance = null_covariance),
    both = data.frame(simulation = seq_len(n_sims),
                      correlation = null_correlation,
                      covariance = null_covariance)
  )
  
  if (test_uncentered_intercept==TRUE){empirical_fits$intercept_tested <- empirical_intercepts}
  
  result <- list(
    call = match.call(),
    statistic_requested = statistic,
    alternative = alternative,
    summary = summary_selected,
    empirical = c(correlation = empirical_correlation,
                  covariance = empirical_covariance),
    null_distribution = null_selected,
    empirical_group_fits = empirical_fits,
    null_parameters = list(
      mean_intercept = beta_hat[1],
      mean_slope = beta_hat[2],
      intercept_variance = variances_hat[1],
      slope_variance = variances_hat[2],
      latent_intercept_slope_covariance = 0,
      residual_variance = variances_hat[3]
    ),
    predictor_center = x_center,
    diagnostics = list(
      optimizer_convergence = opt$convergence,
      optimizer_message = opt$message,
      negative_log_likelihood = opt$value,
      groups_used = n_groups,
      observations_used = nrow(dat),
      rows_removed_missing_or_nonfinite = n_removed_missing,
      groups_excluded = excluded_groups
    ),
    simulated_group_fits = simulated_fits
  )
  class(result) <- "reaction_norm_null_test"
  result
}

# A small infix helper used only for an optional optimizer message.
`%||%` <- function(x, y) if (is.null(x) || length(x) == 0L || !nzchar(x)) y else x


# Print a concise result while preserving all detailed components in the object.
print.reaction_norm_null_test <- function(x, digits = 4, ...) {
  cat("Reaction-norm slope-intercept null test\n")
  cat("-------------------------------------------\n")
  cat("Groups used:", x$diagnostics$groups_used, "\n")
  cat("Observations used:", x$diagnostics$observations_used, "\n")
  cat("Predictor centre:", format(x$predictor_center, digits = digits), "\n")
  cat("Optimizer convergence code:", x$diagnostics$optimizer_convergence, "\n\n")
  print(x$summary, digits = digits, row.names = FALSE)
  invisible(x)
}


# Optional base-R plotting method for the requested null distribution(s).
plot.reaction_norm_null_test <- function(x, bins = 30, ...) {
  
  requested <- x$statistic_requested
  
  stats <- if (requested == "both") {
    c("correlation", "covariance")
  } else {
    requested
  }
  
  # Combine the requested null distributions into long format.
  plot_data <- do.call(
    rbind,
    lapply(stats, function(st) {
      
      z <- x$null_distribution[[st]]
      z <- z[is.finite(z)]
      
      data.frame(
        statistic = st,
        value = z,
        stringsAsFactors = FALSE
      )
    })
  )
  
  rownames(plot_data) <- NULL
  
  # Set readable facet labels and preserve their order.
  plot_data$statistic <- factor(
    plot_data$statistic,
    levels = stats,
    labels = stats
  )
  
  # Create one annotation row for each requested statistic.
  annotation_data <- do.call(
    rbind,
    lapply(stats, function(st) {
      
      z <- x$null_distribution[[st]]
      z <- z[is.finite(z)]
      
      data.frame(
        statistic_name = st,
        statistic = paste("Null", st),
        observed = x$empirical[[st]],
        null_median = median(z),
        stringsAsFactors = FALSE
      )
    })
  )
  
  annotation_data$statistic <- factor(
    annotation_data$statistic_name,
    levels = stats,
    labels = stats
  )
  
  
  
  # Construct and return the ggplot object.
  p <- ggplot2::ggplot(
    plot_data,
    ggplot2::aes(x = value)
  ) +
    ggplot2::geom_histogram(
      bins = bins,
      fill = "grey80",
      color = "grey25",
      linewidth = 0.3
    ) +
    
    # Solid red line for the empirical statistic.
    ggplot2::geom_vline(
      data = annotation_data,
      ggplot2::aes(xintercept = observed),
      color = "firebrick",
      linewidth = 1
    ) +
    
    # Dashed blue line for the null median.
    ggplot2::geom_vline(
      data = annotation_data,
      ggplot2::aes(xintercept = null_median),
      color = "navy",
      linewidth = 1,
      linetype = "dashed"
    ) +
    
    # Show one panel for each statistic when statistic = "both".
    ggplot2::facet_wrap(
      ~ statistic,
      scales = "free_x",
      nrow = 1,
      strip.position = "bottom"
    ) +
    
    ggplot2::labs(
      x = NULL,
      y = "Count",
      color = NULL,
      linetype = NULL
    ) +
    
    ggplot2::theme_minimal(base_size = 12) +
    
    ggplot2::theme(
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major.x = ggplot2::element_blank(),
      strip.text = ggplot2::element_text(face = "bold"),
      legend.position = "top"
    )
  
  # Add a legend using invisible mapped lines. The actual vertical lines above
  # use annotation-specific x-intercepts.
  legend_data <- data.frame(
    label = c("Empirical", "Null median"),
    x = NA_real_
  )
  
  p <- p +
    ggplot2::geom_vline(
      data = legend_data,
      ggplot2::aes(
        xintercept = x,
        color = label,
        linetype = label
      ),
      linewidth = 1,
      show.legend = TRUE
    ) +
    ggplot2::scale_color_manual(
      name = NULL,
      values = c(
        "Empirical" = "firebrick",
        "Null median" = "navy"
      )
    ) +
    ggplot2::scale_linetype_manual(
      name = NULL,
      values = c(
        "Empirical" = "solid",
        "Null median" = "dashed"
      )
    )
  
  return(p)
}


# EXAMPLE
# This synthetic example has an intentionally *uncorrelated* latent intercept and
# slope distribution. It also uses an unbalanced sampling design, demonstrating
# that the function reproduces the exact observed group/predictor structure.
# 
# if (interactive()) {
#   set.seed(42)
# 
#   n_groups <- 60
#   group_ids <- paste0("line_", seq_len(n_groups))
# 
#   # Independent latent reaction-norm parameters under the data-generating model.
#   true_intercepts <- rnorm(n_groups, mean = 3.0, sd = 0.7)
#   true_slopes <- rnorm(n_groups, mean = -0.06, sd = 0.018)
# 
#   # Build an unbalanced design: each line has observations at 3-5 predictor
#   # values, and each line-by-predictor combination has 2-5 replicates.
#   example_parts <- vector("list", n_groups)
#   for (g in seq_len(n_groups)) {
#     temperatures <- sort(sample(36:40, size = sample(3:5, 1)))
#     rows_g <- do.call(rbind, lapply(temperatures, function(temp) {
#       data.frame(
#         line = group_ids[g],
#         temperature = temp,
#         replicate = seq_len(sample(2:5, 1))
#       )
#     }))
#     rows_g$response <- true_intercepts[g] +
#       true_slopes[g] * rows_g$temperature +
#       rnorm(nrow(rows_g), mean = 0, sd = 0.12)
#     example_parts[[g]] <- rows_g
#   }
#   example_data <- do.call(rbind, example_parts)
#   rownames(example_data) <- NULL
# 
#   # Run the test. Use n_sims = 5000 or more for a final analysis. A fixed seed
#   # makes both null-model simulation and the resulting p-value reproducible.
#   example_result <- reaction_norm_null_test(
#     data = example_data,
#     response = "response",
#     predictor = "temperature",
#     group = "line",
#     statistic = "both",             # "correlation", "covariance", or "both"
#     n_sims = 1000,
#     center_predictor = TRUE,         # intercept is response at mean temperature
#     seed = 123,
#     progress = TRUE
#   )
# 
#   print(example_result)
#   plot(example_result)
# 
#   # Useful returned components:
#   head(example_result$null_distribution)
#   head(example_result$empirical_group_fits)
#   example_result$null_parameters
#   example_result$summary



















#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Mixed effects version

# Parametric-bootstrap test of random intercept-slope correlation/covariance
#
# The null model must retain random intercept and slope variation for the focal
# grouping factor but constrain their covariance to zero. The full model must
# allow that covariance. Both models must be Gaussian lme4::lmer() fits using
# the same observations in the same order.

.extract_re_statistic <- function(model, focal_group, slope_term,
                                  statistic = c("correlation", "covariance")) {
  statistic <- match.arg(statistic)
  vc_list <- lme4::VarCorr(model)

  if (!focal_group %in% names(vc_list)) {
    stop(
      "focal_group '", focal_group,
      "' was not found in VarCorr(model). Available groups: ",
      paste(names(vc_list), collapse = ", ")
    )
  }

  vc <- as.matrix(vc_list[[focal_group]])

  if (!all(c("(Intercept)", slope_term) %in% rownames(vc))) {
    stop(
      "The full/refitted model must contain a random intercept and random ",
      "slope named '", slope_term, "' for group '", focal_group, "'."
    )
  }

  if (statistic == "covariance") {
    value <- vc["(Intercept)", slope_term]
  } else {
    sd_intercept <- sqrt(vc["(Intercept)", "(Intercept)"])
    sd_slope <- sqrt(vc[slope_term, slope_term])
    denominator <- sd_intercept * sd_slope

    if (!is.finite(denominator) || denominator <= 0) {
      return(NA_real_)
    }

    value <- vc["(Intercept)", slope_term] / denominator
  }

  if (is.finite(value)) unname(value) else NA_real_
}

.extract_full_group_coefficients <- function(model, focal_group, slope_term) {
  random_effects <- lme4::ranef(model)[[focal_group]]
  fixed_effects <- lme4::fixef(model)

  if (is.null(random_effects)) {
    stop("focal_group was not found in ranef(full_model).")
  }

  required_random <- c("(Intercept)", slope_term)
  required_fixed <- c("(Intercept)", slope_term)

  if (!all(required_random %in% colnames(random_effects))) {
    stop("The focal group lacks the requested random intercept or slope.")
  }

  if (!all(required_fixed %in% names(fixed_effects))) {
    stop("The fixed effects lack the requested intercept or slope term.")
  }

  data.frame(
    group = rownames(random_effects),
    intercept = unname(
      fixed_effects["(Intercept)"] + random_effects[, "(Intercept)"]
    ),
    slope = unname(
      fixed_effects[slope_term] + random_effects[, slope_term]
    ),
    stringsAsFactors = FALSE
  )
}

identifiability_test_mixed <- function(
    full_model,
    null_model,
    data,
    n_sim = 1000L,
    statistic = c("correlation", "covariance"),
    focal_group,
    slope_term,
    seed = 1L,
    tags = c("A", "B", "C"),
    labels = c("Predictor", "Response"),
    plot_type = c("density", "histogram"),
    bins = 40L,
    null_x_limits = NULL,
    exclude_singular = FALSE,
    singular_tol = 1e-4,
    reml = lme4::isREML(full_model),
    finite_correction = TRUE,
    optimizer = "bobyqa",
    maxfun = 200000L,
    line_color = "hotpink",
    observed_color = "blue") {

  if (!requireNamespace("lme4", quietly = TRUE)) {
    stop("Package 'lme4' is required.")
  }
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("Package 'ggplot2' is required.")
  }
  if (!requireNamespace("patchwork", quietly = TRUE)) {
    stop("Package 'patchwork' is required.")
  }

  statistic <- match.arg(statistic)
  plot_type <- match.arg(plot_type)

  if (!inherits(full_model, "lmerMod") || !inherits(null_model, "lmerMod")) {
    stop("full_model and null_model must both be fitted with lme4::lmer().")
  }
  if (!is.data.frame(data)) {
    stop("data must be a data frame.")
  }
  if (length(n_sim) != 1L || !is.finite(n_sim) || n_sim < 1) {
    stop("n_sim must be a positive integer.")
  }
  n_sim <- as.integer(n_sim)

  if (length(tags) != 3L) {
    stop("tags must contain exactly three panel labels.")
  }
  if (length(labels) != 2L) {
    stop("labels must contain predictor and response labels.")
  }
  if (!is.character(focal_group) || length(focal_group) != 1L) {
    stop("focal_group must be one character string.")
  }
  if (!is.character(slope_term) || length(slope_term) != 1L) {
    stop("slope_term must be one character string.")
  }
  if (!slope_term %in% names(data) || !is.numeric(data[[slope_term]])) {
    stop("slope_term must name a numeric column in data.")
  }
  if (!focal_group %in% names(data)) {
    stop("focal_group must name a column in data.")
  }
  if (!is.null(null_x_limits) &&
      (length(null_x_limits) != 2L || any(!is.finite(null_x_limits)) ||
       null_x_limits[1L] >= null_x_limits[2L])) {
    stop("null_x_limits must contain two increasing finite values.")
  }

  full_formula <- stats::formula(full_model)
  null_formula <- stats::formula(null_model)

  response_vars <- all.vars(full_formula[[2L]])
  null_response_vars <- all.vars(null_formula[[2L]])

  if (length(response_vars) != 1L || length(null_response_vars) != 1L ||
      response_vars[[1L]] != null_response_vars[[1L]]) {
    stop(
      "Both models must use the same single, untransformed response column."
    )
  }
  response_name <- response_vars[[1L]]

  if (!response_name %in% names(data)) {
    stop("The response column is absent from data.")
  }
  if (nrow(data) != stats::nobs(full_model) ||
      nrow(data) != stats::nobs(null_model)) {
    stop(
      "data must contain exactly the observations used by both models, in ",
      "the same order. Remove omitted rows before fitting both models."
    )
  }

  # Verify that both fitted models refer to the same response observations.
  full_response <- stats::model.response(stats::model.frame(full_model))
  null_response <- stats::model.response(stats::model.frame(null_model))
  if (!isTRUE(all.equal(as.numeric(full_response), as.numeric(null_response)))) {
    stop("full_model and null_model do not use the same response observations.")
  }

  observed_statistic <- .extract_re_statistic(
    full_model,
    focal_group,
    slope_term,
    statistic
  )
  if (!is.finite(observed_statistic)) {
    stop("The empirical full-model statistic is nonfinite.")
  }

  observed_coefficients <- .extract_full_group_coefficients(
    full_model,
    focal_group,
    slope_term
  )

  predictor_sd <- stats::sd(data[[slope_term]], na.rm = TRUE)
  if (!is.finite(predictor_sd) || predictor_sd <= 0) {
    stop("The slope predictor has zero or nonfinite standard deviation.")
  }

  set.seed(seed)
  null_distribution <- rep(NA_real_, n_sim)
  failed_count <- 0L
  singular_count <- 0L

  for (simulation_index in seq_len(n_sim)) {
    # Simulate one complete response vector under the zero-covariance null.
    simulated_response <- 
      stats::simulate(null_model, nsim = 1)

    if (is.null(simulated_response)) {
      failed_count <- failed_count + 1L
      next
    }

    simulated_data <- data
    simulated_data[[response_name]] <- as.numeric(simulated_response$sim_1)

    # Refit the covariance-allowing model so the null distribution reflects
    # the same estimator used for the empirical statistic.
    simulated_full_model <- 
        lme4::lmer(
          formula = full_formula,
          data = simulated_data,
          REML = reml,
          control = lme4::lmerControl(
            optimizer = optimizer,
            optCtrl = list(maxfun = maxfun),
            check.conv.singular = "ignore"
          )
        )
      

    if (is.null(simulated_full_model)) {
      failed_count <- failed_count + 1L
      next
    }

    singular <- lme4::isSingular(
      simulated_full_model,
      tol = singular_tol
    )

    if (singular) {
      singular_count <- singular_count + 1L
      if (isTRUE(exclude_singular)) {
        next
      }
    }
    
    null_distribution[simulation_index] <-
    .extract_re_statistic(
      simulated_full_model,
      focal_group,
      slope_term,
      statistic
    )


}
  null_distribution <- null_distribution[is.finite(null_distribution)]
  n_valid <- length(null_distribution)

  if (n_valid == 0L) {
    stop("No simulation produced a finite null statistic.")
  }
  if (n_valid < 0.5 * n_sim) {
    warning(
      "Fewer than half of simulations were usable: ",
      n_valid, "/", n_sim, "."
    )
  }

  null_median <- stats::median(null_distribution)

  # Two-sided empirical-tail p-value. This remains valid when the simulated
  # null distribution is asymmetric or not centered exactly at zero.
  if (isTRUE(finite_correction)) {
    p_lower <- (sum(null_distribution <= observed_statistic) + 1) /
      (n_valid + 1)
    p_upper <- (sum(null_distribution >= observed_statistic) + 1) /
      (n_valid + 1)
  } else {
    p_lower <- mean(null_distribution <= observed_statistic)
    p_upper <- mean(null_distribution >= observed_statistic)
  }
  p_value <- min(1, 2 * min(p_lower, p_upper))
  #95% conf int
  confint = quantile(null_distribution, probs = c(0.025, 0.975))

  # Requested B statistic. Note that this divides a dimensionless correlation
  # or a response^2/predictor covariance by predictor units, so it should be
  # treated as a custom index rather than a conventional standardized effect.
  B <- (observed_statistic - null_median) / predictor_sd

  # Panel A: fitted reaction norms for the focal group.
  predictor_grid <- seq(
    min(data[[slope_term]], na.rm = TRUE),
    max(data[[slope_term]], na.rm = TRUE),
    length.out = 100L
  )

  reaction_norms <- do.call(
    rbind,
    lapply(seq_len(nrow(observed_coefficients)), function(i) {
      data.frame(
        predictor = predictor_grid,
        response = observed_coefficients$intercept[i] +
          observed_coefficients$slope[i] * predictor_grid,
        group = observed_coefficients$group[i]
      )
    })
  )

  fixed_effects <- lme4::fixef(full_model)
  population_line <- data.frame(
    predictor = predictor_grid,
    response = unname(fixed_effects["(Intercept)"]) +
      unname(fixed_effects[slope_term]) * predictor_grid
  )

  p1 <- ggplot2::ggplot() +
    ggplot2::geom_line(
      data = reaction_norms,
      ggplot2::aes(x = predictor, y = response, group = group),
      color = line_color,
      alpha = 0.12,
      linewidth = 0.45
    ) +
    ggplot2::geom_line(
      data = population_line,
      ggplot2::aes(x = predictor, y = response),
      color = line_color,
      linewidth = 1.2
    ) +
    ggplot2::labs(
      x = labels[1L],
      y = labels[2L],
      tag = tags[1L]
    ) +
    ggplot2::theme_classic()

  # Panel B: observed joint density of fitted group intercepts and slopes.
  p2 <- ggplot2::ggplot(
    observed_coefficients,
    ggplot2::aes(x = intercept, y = slope)
  ) +
    ggplot2::stat_density_2d(
      ggplot2::aes(fill = ggplot2::after_stat(level)),
      geom = "polygon",
      contour = TRUE,
      na.rm = TRUE
    ) +
    ggplot2::geom_point(
      color = "black",
      alpha = 0.35,
      size = 1
    ) +
    ggplot2::scale_fill_viridis_c() +
    ggplot2::labs(
      x = "Estimated intercept",
      y = "Estimated slope",
      fill = "Density",
      tag = tags[2L]
    ) +
    ggplot2::theme_classic() +
    ggplot2::theme(legend.position = "none")

  # Panel C: null distribution and empirical statistic.
  null_plot_data <- data.frame(value = null_distribution)

  if (plot_type == "density") {
    p3 <- ggplot2::ggplot(
      null_plot_data,
      ggplot2::aes(x = value)
    ) +
      ggplot2::geom_density(
        fill = "grey80",
        color = "black",
        alpha = 0.85,
        na.rm = TRUE
      ) +
      ggplot2::labs(y = "Density")
  } else {
    p3 <- ggplot2::ggplot(
      null_plot_data,
      ggplot2::aes(x = value)
    ) +
      ggplot2::geom_histogram(
        fill = "grey80",
        color = "black",
        bins = bins
      ) +
      ggplot2::labs(y = "Frequency")
  }

  x_axis_label <- if (statistic == "correlation") {
    "Random intercept-slope correlation"
  } else {
    "Random intercept-slope covariance"
  }

  p3 <- p3 +
    ggplot2::geom_vline(
      xintercept = observed_statistic,
      color = observed_color,
      linewidth = 1.2
    ) +
    ggplot2::geom_vline(
      xintercept = null_median,
      color = "black",
      linetype = "dashed",
      linewidth = 0.8
    ) +
    ggplot2::labs(
      title = paste0(
        "two-sided p = ", format.pval(p_value, digits = 3)
      ),
      subtitle = paste0(
        "B = ", signif(B, 3),
        "; valid = ", n_valid, "/", n_sim,
        "; singular = ", singular_count
      ),
      x = x_axis_label,
      tag = tags[3L]
    ) +
    ggplot2::theme_classic()+
    xlim(c(-1,1))

  if (!is.null(null_x_limits)) {
    p3 <- p3 + ggplot2::coord_cartesian(xlim = null_x_limits)
  }

  combined_plot <- patchwork::wrap_plots(p1, p2, p3, nrow = 1)

  list(
    null_distribution = null_distribution,
    p_value = p_value,
    B = B,
    figure = combined_plot,
    null_figure = p3,
    confint = confint,
    observed_statistic = observed_statistic
  )
}

# Example -----------------------------------------------------------------
#
# full_model <- lme4::lmer(
#   response ~ predictor + (1 + predictor | group),
#   data = dat,
#   REML = TRUE
# )
#
# null_model <- lme4::lmer(
#   response ~ predictor +
#     (1 | group) +
#     (0 + predictor | group),
#   data = dat,
#   REML = TRUE
# )
#
# result <- identifiability_test_mixed(
#   full_model = full_model,
#   null_model = null_model,
#   data = dat,
#   n_sim = 2000,
#   statistic = "correlation",
#   focal_group = "group",
#   slope_term = "predictor",
#   labels = c("Predictor", "Response"),
#   seed = 1,
#   exclude_singular = FALSE
# )
#
# result$p_value
# result$B
# result$figure
