

# Title of Dataset: Female reproductive fluids ‘rescue’ sperm from phenotypic ageing in an external fertiliser
---

We conducted an experiment designed to test the interactive effects of post-ejaculatory sperm ageing and egg-derived fluids on sperm motility in the blue mussel, *Mytilus galloprovincialis*. The experiment comprised of seven blocks, in which ejaculates were aged in seawater and then tested in two environmental treatments. We repeatedly tested sperm motility in either seawater or 'egg water' (seawater containing egg-derived fluids), and at four different ages, using computer-assisted sperm analysis (CASA). Because sperm age as they are diluted, a phenomenon known as the respiratory dilution effect, we used the time since dilution (while controlling for differences in spawning time) as a proxy for sperm age.

Sperm motility was first analysed immediately after dilution, with three subsequent repeats occurring approximately 1 h apart (tests occurred at approximately 0, 1, 2, and 3 hrs post-dilution). For each test, subsamples of ageing ejaculate were added to 1) a seawater control and 2) egg water (pooled from multiple females) for motility assays. Each male’s ejaculate was therefore analysed eight times: in two environmental treatments and at four ages. Each block consisted of ejaculates from 5-7 replicate males, and a pool of egg water from 5-6 females. Using pooled egg water controls for among-female variation in egg quality, and for male-by-female interaction effects that occur in *M. galloprovincialis*. Over the seven experimental blocks we obtained a total sample size of n = 43 males tested across the different environment and age combinations (344 assays in total).


## Description of the Data and file structure

The dataset contains variables in column and samples in rows. Column names and there descriptions are as follows:
- analysis_time: a time stamp for the motility analyses
- date: the date the sample was taken, in the format DDMM
- egg_pool: block ID
- animal_id: a unique ID for each motility analysis. e.g. for the ID '1407101.1.S': '1407' represents the block date, '101' represents a separate individual in the block, '.1.S' means the first track (for this male) in seawater. For the ID '1607102.4.E': '1607' is the date of the block, '102' is an individual from the block, '.4.E' is the fourth track in egg water
- spawn_time: the approximate time, in minutes, that an individual mussel spawned after being placed in the spawning tub (a tub warmed to 26 degrees celcius to induce spawning)
- motility_time: the approximate time, in minutes, that the corresponding motility analysis was performed
- motile_count: the number of motile sperm tracked 
- motile_mean_alh: mean amplitude of lateral head placement of motile sperm (ALH, μm)
- motile_mean_bcf: mean beat cross frequency of motile sperm (BCF, beats/second)
- motile_mean_lin: mean linearity of motile sperm (LIN, VCL/VAP)
- motile_mean_str: mean straightness of motile sperm (STR, VSL/VAP) 
- motile_mean_vap: mean average path velocity of motile sperm (VAP, μm/second)
- motile_mean_vcl: mean curvilinear velocity of motile sperm (VCL, μm/second)
- motile_mean_vsl: mean straight line velocity of motile sperm (VSL, μm/second)
- motile_mean_wob: mean wobble of motile sperm (WOB, VAP/VCL)
- motile_percent_of_total: proportion of motile sperm in sample (PM, %)
- total_count: total number of sperm in sample (motile and immotile)



## Sharing/access Information

Links to other publicly accessible locations of the data: see published article

Was data derived from another source? no
