
  data{
  int<lower=1> N;
  int<lower=1> N_id;
  int ID[N];
  real WEEK[N];
  real Y[N];
  }
  parameters{
  real beta_0;
  real beta_1;
  real gamma_0;
  vector[2] re_id[N_id];
  vector<lower=0>[2] sd_id;
  real re_id2[N_id];
  real<lower=0> sd_id2;
  real<lower=0> sigma; 
  corr_matrix[2] id_cor;             
  }
  model{
  vector[N] muy;
  vector[N] sdy;
  beta_0 ~ normal(0, 100); 
  beta_1 ~ normal(0, 100);
  gamma_0 ~ normal(0, 100);
  sd_id ~ cauchy(0, 5);
  sd_id2 ~ cauchy(0, 5);
  sigma ~ cauchy(0, 5);
  id_cor ~ lkj_corr(2);
  re_id ~ multi_normal(rep_vector(0, 2), quad_form_diag(id_cor, sd_id)); 
  re_id2 ~ normal(0, sd_id2);
  for (i in 1:N){
  muy[i] = beta_0 + beta_1 * WEEK[i] + re_id[ID[i],1] + re_id[ID[i],2] * WEEK[i];
  sdy[i] = exp(gamma_0 + re_id2[ID[i]]);
  }
  Y ~ normal(muy, sdy);              
  }
  generated quantities{
  real R;
  R = sd_id[1]^2 / (sd_id[1]^2 + exp(gamma_0)^2);
  }


