# ==============================================================================
# Reaction-norm slope-intercept null test
# ==============================================================================
#
# Purpose
# -------
# Test whether an empirical association between group-specific reaction-norm
# intercepts and slopes is more extreme than expected when the *latent* group
# intercepts and slopes are uncorrelated.
#
# The procedure is a parametric bootstrap:
#   1. Fit response ~ predictor separately within each group.
#   2. Estimate an independent random-intercept/random-slope null model by
#      maximum likelihood while retaining the observed sampling design.
#   3. Simulate many complete response vectors under that null model using the
#      exact predictor values, group sizes, imbalance, and replication in the
#      supplied data.
#   4. Refit the within-group regressions after every simulation.
#   5. Build null distributions of recovered slope-intercept correlations and/or
#      covariances.
#   6. Calculate Monte Carlo two-tailed p-values relative to the centre of each
#      induced null distribution.
#
# No contributed R packages are required.
#
# Important interpretation
# ------------------------
# The null hypothesis concerns the intercept at predictor == 0. Changing the
# predictor's origin changes the intercept and therefore may change its
# association with slope. Use center_predictor = TRUE to define the intercept at
# the overall mean predictor value, or supply predictor_center explicitly.
#
# This function assumes Gaussian latent intercepts, latent slopes, and residuals.
# It keeps the observed design fixed but does not automatically model nonlinear
# reaction norms, heteroscedasticity, temporal/spatial dependence, phylogeny, or
# nested/crossed random effects.
# ==============================================================================

reaction_norm_null_test <- function(
    data,
    response,
    predictor,
    group,
    statistic = c("correlation", "covariance", "both"),
    n_sims = 2000L,
    center_predictor = FALSE,
    predictor_center = NULL,
    min_group_n = 3L,
    seed = NULL,
    optimizer_control = list(maxit = 1000),
    keep_simulated_fits = FALSE,
    progress = interactive()
) {
  # ---------------------------------------------------------------------------
  # 0. Validate arguments and capture column names
  # ---------------------------------------------------------------------------
  if (!is.data.frame(data)) stop("`data` must be a data.frame.")

  # Accept either bare names, e.g. response = y, or strings, e.g. response = "y".
  # We inspect the unevaluated expression so a bare column name need not exist as
  # a separate object in the calling environment.
  get_col_name <- function(arg_expr) {
    if (is.character(arg_expr) && length(arg_expr) == 1L) return(arg_expr)
    deparse(arg_expr)
  }

  response_name  <- get_col_name(substitute(response))
  predictor_name <- get_col_name(substitute(predictor))
  group_name     <- get_col_name(substitute(group))

  needed <- c(response_name, predictor_name, group_name)
  missing_cols <- setdiff(needed, names(data))
  if (length(missing_cols) > 0L) {
    stop("Columns not found in `data`: ", paste(missing_cols, collapse = ", "))
  }

  statistic <- match.arg(statistic)
  n_sims <- as.integer(n_sims)
  min_group_n <- as.integer(min_group_n)
  if (!is.finite(n_sims) || n_sims < 1L) stop("`n_sims` must be at least 1.")
  if (!is.finite(min_group_n) || min_group_n < 2L) {
    stop("`min_group_n` must be at least 2.")
  }
  if (!is.null(seed)) set.seed(seed)

  # Make a small internal data frame with stable names. Rows with missing or
  # non-finite response/predictor values, or missing groups, cannot be fitted.
  dat <- data.frame(
    y = data[[response_name]],
    x_original = data[[predictor_name]],
    group = data[[group_name]],
    stringsAsFactors = FALSE
  )

  if (!is.numeric(dat$y)) stop("The response column must be numeric.")
  if (!is.numeric(dat$x_original)) stop("The predictor column must be numeric.")

  keep <- is.finite(dat$y) & is.finite(dat$x_original) & !is.na(dat$group)
  n_removed_missing <- sum(!keep)
  dat <- dat[keep, , drop = FALSE]
  if (nrow(dat) == 0L) stop("No complete, finite observations remain.")

  # Define the predictor origin. predictor_center has precedence. This is useful
  # because slope-intercept covariance depends strongly on the predictor origin.
  if (!is.null(predictor_center)) {
    if (length(predictor_center) != 1L || !is.finite(predictor_center)) {
      stop("`predictor_center` must be one finite number.")
    }
    x_center <- as.numeric(predictor_center)
  } else if (isTRUE(center_predictor)) {
    x_center <- mean(dat$x_original)
  } else {
    x_center <- 0
  }
  dat$x <- dat$x_original - x_center

  # Retain only groups capable of yielding a slope: enough rows and at least two
  # distinct predictor values. The same retained design is used in every bootstrap.
  split_initial <- split(dat, dat$group, drop = TRUE)
  valid_group <- vapply(
    split_initial,
    function(d) nrow(d) >= min_group_n && length(unique(d$x)) >= 2L,
    logical(1)
  )
  excluded_groups <- names(split_initial)[!valid_group]
  group_data <- split_initial[valid_group]
  if (length(group_data) < 3L) {
    stop("At least three valid groups are required to estimate an association.")
  }

  # Recombine and create integer group IDs. `group_data` preserves each group's
  # original row-level predictor pattern, including imbalance and replication.
  dat <- do.call(rbind, group_data)
  rownames(dat) <- NULL
  group_labels <- names(group_data)
  n_groups <- length(group_data)

  # ---------------------------------------------------------------------------
  # 1. Helper: fit separate OLS reaction norms and extract intercepts/slopes
  # ---------------------------------------------------------------------------
  fit_group_lines <- function(y_by_group, x_by_group, labels) {
    out <- matrix(NA_real_, nrow = length(labels), ncol = 2L,
                  dimnames = list(NULL, c("intercept", "slope")))
    for (g in seq_along(labels)) {
      Xg <- cbind(1, x_by_group[[g]])
      # qr.coef is numerically stable and avoids repeatedly constructing lm objects.
      out[g, ] <- qr.coef(qr(Xg), y_by_group[[g]])
    }
    data.frame(
      group = labels,
      intercept = out[, "intercept"],
      slope = out[, "slope"],
      stringsAsFactors = FALSE
    )
  }

  x_by_group <- lapply(group_data, `[[`, "x")
  y_by_group <- lapply(group_data, `[[`, "y")
  empirical_fits <- fit_group_lines(y_by_group, x_by_group, group_labels)

  # Defensive check. This should not fail after the group validity screening.
  finite_fit <- is.finite(empirical_fits$intercept) & is.finite(empirical_fits$slope)
  if (sum(finite_fit) < 3L) stop("Fewer than three finite group fits were obtained.")
  empirical_fits <- empirical_fits[finite_fit, , drop = FALSE]

  empirical_correlation <- cor(empirical_fits$intercept, empirical_fits$slope)
  empirical_covariance  <- cov(empirical_fits$intercept, empirical_fits$slope)

  # ---------------------------------------------------------------------------
  # 2. Fit the independent latent intercept/slope null by maximum likelihood
  # ---------------------------------------------------------------------------
  # Model for group g:
  #   y_g = X_g beta + X_g b_g + e_g
  #   b_g ~ N(0, diag(tau_intercept^2, tau_slope^2))
  #   e_g ~ N(0, sigma_e^2 I)
  #
  # Thus y_g marginally follows:
  #   N(X_g beta, X_g D X_g' + sigma_e^2 I)
  # where D is diagonal. The diagonal D explicitly imposes zero latent
  # slope-intercept covariance. We maximize the marginal likelihood by `optim`.

  X_by_group <- lapply(x_by_group, function(x) cbind(1, x))

  # Starting fixed effects come from an ordinary regression over all retained rows.
  beta_start <- as.numeric(qr.coef(qr(cbind(1, dat$x)), dat$y))
  if (any(!is.finite(beta_start))) stop("Could not obtain starting fixed effects.")

  # Obtain stable positive starting variances. The residual start is pooled across
  # group-specific regressions. Latent starts use the empirical spread of fits.
  rss <- 0
  residual_df <- 0L
  for (g in seq_along(group_data)) {
    Xg <- X_by_group[[g]]
    yg <- y_by_group[[g]]
    bg <- qr.coef(qr(Xg), yg)
    rss <- rss + sum((yg - drop(Xg %*% bg))^2)
    residual_df <- residual_df + nrow(Xg) - 2L
  }
  total_var <- var(dat$y)
  variance_floor <- max(total_var, 1, na.rm = TRUE) * 1e-10
  sigma2_start <- if (residual_df > 0L) rss / residual_df else total_var / 4
  sigma2_start <- max(sigma2_start, variance_floor)
  tau_a2_start <- max(var(empirical_fits$intercept) / 2, variance_floor)
  tau_b2_start <- max(var(empirical_fits$slope) / 2, variance_floor)

  # Parameters are beta0, beta1, log(tau_a^2), log(tau_b^2), log(sigma_e^2).
  # Log-variances guarantee positive variance estimates during optimization.
  neg_log_likelihood <- function(par) {
    beta <- par[1:2]
    variance_values <- exp(par[3:5])
    if (any(!is.finite(variance_values))) return(.Machine$double.xmax / 100)
    D <- diag(variance_values[1:2], nrow = 2L)
    sigma2 <- variance_values[3]
    nll <- 0

    for (g in seq_along(X_by_group)) {
      Xg <- X_by_group[[g]]
      yg <- y_by_group[[g]]
      Vg <- Xg %*% D %*% t(Xg) + diag(sigma2, nrow(Xg))
      R <- tryCatch(chol(Vg), error = function(e) NULL)
      if (is.null(R)) return(.Machine$double.xmax / 100)
      residual <- yg - drop(Xg %*% beta)
      # If R'R = V, then ||solve(R', residual)||^2 = residual' V^-1 residual.
      z <- forwardsolve(t(R), residual)
      log_det <- 2 * sum(log(diag(R)))
      nll <- nll + 0.5 * (length(yg) * log(2 * pi) + log_det + sum(z^2))
    }
    nll
  }

  start <- c(beta_start,
             log(tau_a2_start), log(tau_b2_start), log(sigma2_start))
  opt <- optim(
    par = start,
    fn = neg_log_likelihood,
    method = "BFGS",
    control = optimizer_control,
    hessian = FALSE
  )
  if (opt$convergence != 0L || !is.finite(opt$value)) {
    warning("Null-model optimization did not report clean convergence: ",
            opt$message %||% paste("convergence code", opt$convergence))
  }

  beta_hat <- unname(opt$par[1:2])
  names(beta_hat) <- c("mean_intercept", "mean_slope")
  variances_hat <- exp(opt$par[3:5])
  names(variances_hat) <- c("intercept_variance", "slope_variance",
                            "residual_variance")

  # ---------------------------------------------------------------------------
  # 3. Parametric bootstrap under zero latent intercept-slope covariance
  # ---------------------------------------------------------------------------
  null_correlation <- rep(NA_real_, n_sims)
  null_covariance  <- rep(NA_real_, n_sims)

  if (isTRUE(keep_simulated_fits)) {
    simulated_fits <- vector("list", n_sims)
  } else {
    simulated_fits <- NULL
  }

  progress_points <- if (isTRUE(progress) && n_sims >= 10L) {
    unique(round(seq(1, n_sims, length.out = 11L))[-1L])
  } else integer(0)

  for (s in seq_len(n_sims)) {
    # Draw independent latent deviations. Independence is the biological/statistical
    # null; any association among the subsequently recovered OLS coefficients is
    # generated by their shared design and observation error.
    latent_intercept <- rnorm(
      n_groups, mean = beta_hat[1], sd = sqrt(variances_hat[1])
    )
    latent_slope <- rnorm(
      n_groups, mean = beta_hat[2], sd = sqrt(variances_hat[2])
    )

    sim_y <- vector("list", n_groups)
    for (g in seq_len(n_groups)) {
      xg <- x_by_group[[g]]
      sim_y[[g]] <- latent_intercept[g] + latent_slope[g] * xg +
        rnorm(length(xg), mean = 0, sd = sqrt(variances_hat[3]))
    }

    recovered <- fit_group_lines(sim_y, x_by_group, group_labels)
    good <- is.finite(recovered$intercept) & is.finite(recovered$slope)
    recovered <- recovered[good, , drop = FALSE]

    if (nrow(recovered) >= 3L &&
        sd(recovered$intercept) > 0 && sd(recovered$slope) > 0) {
      null_correlation[s] <- cor(recovered$intercept, recovered$slope)
      null_covariance[s]  <- cov(recovered$intercept, recovered$slope)
    }
    if (isTRUE(keep_simulated_fits)) simulated_fits[[s]] <- recovered

    if (s %in% progress_points) {
      message(sprintf("Parametric bootstrap: %d%% complete",
                      round(100 * s / n_sims)))
    }
  }

  # ---------------------------------------------------------------------------
  # 4. Two-tailed Monte Carlo p-values
  # ---------------------------------------------------------------------------
  # The recovered null distribution can be centred away from zero because OLS
  # intercept and slope errors are mathematically associated. Therefore, extremity
  # is measured relative to the simulated null centre, not automatically zero.
  # The +1 correction prevents an estimated p-value of exactly zero.
  monte_carlo_p <- function(observed, null_values) {
    z <- null_values[is.finite(null_values)]
    if (length(z) == 0L) return(NA_real_)
    null_center <- mean(z)
    (1 + sum(abs(z - null_center) >= abs(observed - null_center))) /
      (length(z) + 1)
  }

  p_correlation <- monte_carlo_p(empirical_correlation, null_correlation)
  p_covariance  <- monte_carlo_p(empirical_covariance, null_covariance)

  summary_all <- data.frame(
    statistic = c("correlation", "covariance"),
    empirical = c(empirical_correlation, empirical_covariance),
    null_mean = c(mean(null_correlation, na.rm = TRUE),
                  mean(null_covariance, na.rm = TRUE)),
    null_median = c(median(null_correlation, na.rm = TRUE),
                    median(null_covariance, na.rm = TRUE)),
    null_sd = c(sd(null_correlation, na.rm = TRUE),
                sd(null_covariance, na.rm = TRUE)),
    null_q025 = c(unname(quantile(null_correlation, 0.025, na.rm = TRUE)),
                  unname(quantile(null_covariance, 0.025, na.rm = TRUE))),
    null_q975 = c(unname(quantile(null_correlation, 0.975, na.rm = TRUE)),
                  unname(quantile(null_covariance, 0.975, na.rm = TRUE))),
    p_value_two_tailed = c(p_correlation, p_covariance),
    valid_simulations = c(sum(is.finite(null_correlation)),
                          sum(is.finite(null_covariance))),
    stringsAsFactors = FALSE
  )

  selected_rows <- switch(
    statistic,
    correlation = 1L,
    covariance = 2L,
    both = 1:2
  )
  summary_selected <- summary_all[selected_rows, , drop = FALSE]
  null_selected <- switch(
    statistic,
    correlation = data.frame(simulation = seq_len(n_sims),
                             correlation = null_correlation),
    covariance = data.frame(simulation = seq_len(n_sims),
                            covariance = null_covariance),
    both = data.frame(simulation = seq_len(n_sims),
                      correlation = null_correlation,
                      covariance = null_covariance)
  )

  result <- list(
    call = match.call(),
    statistic_requested = statistic,
    summary = summary_selected,
    empirical = c(correlation = empirical_correlation,
                  covariance = empirical_covariance),
    null_distribution = null_selected,
    empirical_group_fits = empirical_fits,
    null_parameters = list(
      mean_intercept = beta_hat[1],
      mean_slope = beta_hat[2],
      intercept_variance = variances_hat[1],
      slope_variance = variances_hat[2],
      latent_intercept_slope_covariance = 0,
      residual_variance = variances_hat[3]
    ),
    predictor_center = x_center,
    diagnostics = list(
      optimizer_convergence = opt$convergence,
      optimizer_message = opt$message,
      negative_log_likelihood = opt$value,
      groups_used = n_groups,
      observations_used = nrow(dat),
      rows_removed_missing_or_nonfinite = n_removed_missing,
      groups_excluded = excluded_groups
    ),
    simulated_group_fits = simulated_fits
  )
  class(result) <- "reaction_norm_null_test"
  result
}

# A small infix helper used only for an optional optimizer message.
`%||%` <- function(x, y) if (is.null(x) || length(x) == 0L || !nzchar(x)) y else x


# Print a concise result while preserving all detailed components in the object.
print.reaction_norm_null_test <- function(x, digits = 4, ...) {
  cat("Reaction-norm slope-intercept null test\n")
  cat("-------------------------------------------\n")
  cat("Groups used:", x$diagnostics$groups_used, "\n")
  cat("Observations used:", x$diagnostics$observations_used, "\n")
  cat("Predictor centre:", format(x$predictor_center, digits = digits), "\n")
  cat("Optimizer convergence code:", x$diagnostics$optimizer_convergence, "\n\n")
  print(x$summary, digits = digits, row.names = FALSE)
  invisible(x)
}


# Optional base-R plotting method for the requested null distribution(s).
plot.reaction_norm_null_test <- function(x, ...) {
  requested <- x$statistic_requested
  stats <- if (requested == "both") c("correlation", "covariance") else requested
  old_par <- par(no.readonly = TRUE)
  on.exit(par(old_par), add = TRUE)
  if (length(stats) == 2L) par(mfrow = c(1, 2))

  for (st in stats) {
    z <- x$null_distribution[[st]]
    z <- z[is.finite(z)]
    observed <- x$empirical[[st]]
    hist(z, breaks = "FD", col = "grey85", border = "white",
         main = paste("Null", st), xlab = st, ...)
    abline(v = observed, col = "firebrick", lwd = 2)
    abline(v = mean(z), col = "navy", lwd = 2, lty = 2)
    legend("topright",
           legend = c("Empirical", "Null mean"),
           col = c("firebrick", "navy"), lwd = 2, lty = c(1, 2), bty = "n")
  }
  invisible(x)
}


# ==============================================================================
# EXAMPLE
# ==============================================================================
# This synthetic example has an intentionally *uncorrelated* latent intercept and
# slope distribution. It also uses an unbalanced sampling design, demonstrating
# that the function reproduces the exact observed group/predictor structure.

if (interactive()) {
  set.seed(42)

  n_groups <- 60
  group_ids <- paste0("line_", seq_len(n_groups))

  # Independent latent reaction-norm parameters under the data-generating model.
  true_intercepts <- rnorm(n_groups, mean = 3.0, sd = 0.7)
  true_slopes <- rnorm(n_groups, mean = -0.06, sd = 0.018)

  # Build an unbalanced design: each line has observations at 3-5 predictor
  # values, and each line-by-predictor combination has 2-5 replicates.
  example_parts <- vector("list", n_groups)
  for (g in seq_len(n_groups)) {
    temperatures <- sort(sample(36:40, size = sample(3:5, 1)))
    rows_g <- do.call(rbind, lapply(temperatures, function(temp) {
      data.frame(
        line = group_ids[g],
        temperature = temp,
        replicate = seq_len(sample(2:5, 1))
      )
    }))
    rows_g$response <- true_intercepts[g] +
      true_slopes[g] * rows_g$temperature +
      rnorm(nrow(rows_g), mean = 0, sd = 0.12)
    example_parts[[g]] <- rows_g
  }
  example_data <- do.call(rbind, example_parts)
  rownames(example_data) <- NULL

  # Run the test. Use n_sims = 5000 or more for a final analysis. A fixed seed
  # makes both null-model simulation and the resulting p-value reproducible.
  example_result <- reaction_norm_null_test(
    data = example_data,
    response = "response",
    predictor = "temperature",
    group = "line",
    statistic = "both",             # "correlation", "covariance", or "both"
    n_sims = 1000,
    center_predictor = TRUE,         # intercept is response at mean temperature
    seed = 123,
    progress = TRUE
  )

  print(example_result)
  plot(example_result)

  # Useful returned components:
  head(example_result$null_distribution)
  head(example_result$empirical_group_fits)
  example_result$null_parameters
  example_result$summary

  # Example using a transformed response:
  # soto_data$log_time <- log10(soto_data$time)
  # soto_result <- reaction_norm_null_test(
  #   data = subset(soto_data, sex == "F"),
  #   response = "log_time",
  #   predictor = "Temp",
  #   group = "line",
  #   statistic = "correlation",
  #   n_sims = 5000,
  #   center_predictor = FALSE,  # preserves intercept at Temp == 0
  #   seed = 1
  # )
}
